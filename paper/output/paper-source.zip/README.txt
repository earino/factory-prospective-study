Dataset Factory, November 15 consumer update. Seven pages, 20 references.
Build: sh build.sh (pdfLaTeX and BibTeX required).
Twelve publications; 24 consumer models across eight datasets.
Cost accounting ends at 14:24 UTC and covers the first 11 publications.
Includes wildlife-strike recovery completed at 16:44 UTC.
Further evaluations and semantic review remain outstanding.
