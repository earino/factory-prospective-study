Interim author-review draft, 15 November 2026.
Build with: sh build.sh
Includes all LaTeX, bibliography, table and vector-figure inputs.
Full evidence and analysis: https://github.com/earino/factory-prospective-study (private during drafting).
