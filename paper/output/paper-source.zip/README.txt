Dataset Factory: revised interim seven-page draft, 15 November 2026.
Build with: sh build.sh (requires pdfLaTeX and BibTeX).
Includes the IEEE class/style, 20 cited references, vector figures, and table.
Interim production cutoff: 15 November 2026 at 14:24:01 UTC.
Recovery results and final semantic reviews are not yet incorporated.
The larger source repository contains evidence provenance and analysis code.
