Dataset Factory, November 15 evening update. Seven pages, 20 references.
Build: sh build.sh (pdfLaTeX and BibTeX required).
Twelve publications; 29 scored consumer models across ten datasets.
Seattle has two scored models and one blocked attempt.
Cost accounting ends at 14:24 UTC and covers the first 11 publications.
Includes recoveries completed by 20:08 UTC.
Drinking-water evaluation and final review remain outstanding.
