# Portable AGENT 2027 paper source

Run `sh build.sh` with a LaTeX installation providing pdflatex and bibtex.
The included IEEEtran class/style, figures and generated table require no study
checkout, Python environment, or external data for the PDF build.
The result is `output/paper.pdf`.

Figure-generation scripts and the evidence supporting the paper remain in the
study repository's `paper-agent27-short/` directory. This archive reproduces the
manuscript, not new factory production or new consumer-model trajectories.
